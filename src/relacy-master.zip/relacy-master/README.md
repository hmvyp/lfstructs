# Relacy Race Detector
Meticulous synchronization algorithm verifier for relaxed memory models

http://www.1024cores.net/home/relacy-race-detector
http://www.1024cores.net/home/relacy-race-detector/rrd-introduction
