#pragma once

#define _WIN32_WINNT 0x0500
#include <windows.h>
#include <intrin.h>
#include <stddef.h>

#include "../../relacy/pch.hpp"
#include "../../relacy/relacy_std.hpp"

