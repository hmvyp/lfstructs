#pragma once

#ifdef NDEBUG
#   define _SECURE_SCL 0
#endif

#define RL_MSVC_OUTPUT

#include "../../relacy/pch.hpp"

