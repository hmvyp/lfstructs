#pragma once

#pragma warning (disable: 4201)

//#define RL_GC
#define RL_MSVC_OUTPUT

#include "../../relacy/pch.hpp"
#include "../../relacy/relacy_std.hpp"

