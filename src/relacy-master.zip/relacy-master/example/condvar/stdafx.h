#pragma once

#ifdef NDEBUG
#   define _SECURE_SCL 0
#endif

#define RL_MSVC_OUTPUT
//#define RL_DEBUGBREAK_ON_FAILURE

#include "../../relacy/pch.hpp"
#include "../../relacy/relacy_std.hpp"



